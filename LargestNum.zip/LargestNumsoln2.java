package handson;

import java.util.Scanner;

public class LargestNumsoln2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner keyboard = new Scanner(System.in);
		
		int[] numbers = new int[5];
		int[] sortednums= new int[5];
		System.out.println("Enter the numbers for the array: ");
		for (int i =0 ; i<numbers.length; i++) {
		     numbers[i]= keyboard.nextInt();
		}
		int maxvalue = numbers[0];

		int j=0;
		while(j<numbers.length) {
			int max=numbers[j];
			int index=j;
			
			for(int i=j+1;i<numbers.length;i++) {
				if(max < numbers[i]) {
					max=numbers[i];
					index=i;
				}
			}
			int mem = numbers[j];
			numbers[j] = numbers[index];
			numbers[index] = mem;
			j++;
		}


			for (int m=0;m<numbers.length;m++) {
				System.out.println(numbers[m]);
			}
	}

}
