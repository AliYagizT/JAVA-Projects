package handson;

import java.util.Scanner;

public class LargestNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner keyboard = new Scanner(System.in);
		
int[] numbers = new int[5];
int[] sortednums= new int[5];
System.out.println("Enter the numbers for the array: ");
for (int i =0 ; i<numbers.length; i++) {
     numbers[i]= keyboard.nextInt();
}
int maxvalue = numbers[0];


int max;
int localmax=0;
int dongu=0;
int L=0;
int indexof=0;

while(dongu<5) {
	
for(int i =0;i<numbers.length;i++) {
	localmax=numbers[i];
	
	for(int k=0;k<numbers.length;k++) {
		if(numbers[k]>localmax) {
			localmax=numbers[k];
			indexof=k;
		}
	}
}
sortednums[L]=localmax;
L++;
numbers[indexof]=0;
dongu++;
}


for (int m=0;m<numbers.length;m++) {
	System.out.println(sortednums[m]);
}




}
}


/*int j=0;
while(j<numbers.length) {
	int max=numbers[j];
	int index=j;
	
	for(int i=j+1;i<numbers.length;i++) {
		if(max < numbers[i]) {
			max=numbers[i];
			index=i;
		}
	}
	int mem = numbers[j];
	numbers[j] = numbers[index];
	numbers[index] = mem;
	j++;
}


	for (int m=0;m<numbers.length;m++) {
		System.out.println(numbers[m]);
	}*/