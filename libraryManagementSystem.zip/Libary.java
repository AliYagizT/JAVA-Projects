package handson3;
import java.util.Scanner;

public class Libary {
	public Book[] books = new Book[10];
	public int a = 0;
	
	public void addBook() {
		if (a < 10){
			Scanner keyboard = new Scanner(System.in);		
			System.out.println("Name of the book: ");
			String title= keyboard.nextLine();
			
			System.out.println("Name of the author ");
			String author = keyboard.nextLine();
			
			System.out.println("ISBN of the book");
			int isbn = keyboard.nextInt();
			
			System.out.println("number of pages of this book ");
			String pagenum = keyboard.nextLine();
			keyboard.nextLine();
			
			books[a] = new Book(title,author,isbn,pagenum);
			
			a++;
		} else {
			System.out.println("Yer yok");
		}

	}
	public void displayBooks() {
	if(books[0]==null) {
		System.out.println("no book found");
	}
		for(int i =0;i<a;i++) {
			if(books[i]!= null) {
			System.out.println((i+1) + ". " + books[i]); }
			
			
		}
		
	}
	public void search() {
		Scanner keyboard = new Scanner(System.in);		
		System.out.println("Name of the book: ");
		String title = keyboard.nextLine();
		for(int j =0;j<a;j++) {
			
			if(title.equals(books[j].title)) {
				System.out.println(books[j]);
				break;
			} 
			if(j==(a-1)) {
				System.out.println("book not found");
			}
		}
		
	}
	
	public static void main(String[] args) {
		Libary lib = new Libary();
		Scanner keyboard = new Scanner(System.in);
		boolean exit = true;
		while(exit) {
		System.out.println("What is the operation you want?");
		System.out.println("1 to Add book");
		System.out.println("2 to Search a book by title");
		System.out.println("3 to display all the books");
		System.out.println("4 for exit");
		int input = keyboard.nextInt();
		
		switch (input) {
		case 1:
			lib.addBook();
			break;
		case 2:
			lib.search();
			break;
		case 3:
			lib.displayBooks();
			break;
		case 4:
			exit = false;
			break;
		default:
			System.out.println("Wrong input try again.");
		
		}
		}
		
		
	}
}
