package handson3;

import java.util.Scanner;

public class Book {
public String title;
public String author;
public int isbn;
public String pagenum;

public Book(String title,String author,int isbn,String pagenum) {
	this.title=title;
	this.author=author;
	this.isbn=isbn;
	this.pagenum=pagenum;
}
public String toString() {
	return "name: "+this.title+" author: "+this.author+" isbn "+this.isbn+" pagenum "+this.pagenum;
}




}
